package com.example.user.service;

import java.util.List;

import com.example.user.entity.user;

public interface UserService {

	public List<user> fetchuserList();

	public user fetchuserById(Long userId);

	public void deleteuserById(Long userId);

	public user updateuser(Long userId, user user);

	public user saveUser(user user);

	user updateuser1(Long userId, user user);

	user saveuser(user users);

}

